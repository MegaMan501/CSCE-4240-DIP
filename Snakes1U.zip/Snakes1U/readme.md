# How to use the Snake1U

To run the matlab code. Open up matlab and then set the current directory to the path. 
next run `main` function. 

- For example: 
  ```
  >> main('rose512.tif'); 
  Enter the number of segments: 12

  PRESS ANY KEY TO BEGIN DATA ENTRY. SELECT POINTS WITH THE MOUSE.
  PRESS RETURN TO TERMINATE DATA ENTRY.

  ```
![Step1](https://github.com/MegaMan501/CSCE-4240-DIP/blob/master/Snakes1U/Screenshot%20from%202019-02-01%2015-58-51.png)

At the output should look like this. 

![Step2](https://github.com/MegaMan501/CSCE-4240-DIP/blob/master/Snakes1U/Screenshot%20from%202019-02-01%2016-02-58.png)
